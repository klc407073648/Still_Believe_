// Report 0MQ version in Node.js

var zmq = require('zmq');

console.log("Current 0MQ version is " + zmq.version);

(defproject zguide "1.0.0-SNAPSHOT"
  :source-path "../Clojure/"
  :description "0MQ zguide in Clojure"
  :dependencies [[org.clojure/clojure "1.4.0"]
                 [org.zmq/zmq "2.1.0"]
                 ])

# Permission to Relicense under MPLv2

This is a statement by Steven McCoy
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "steve-o", with
commit author "Steven McCoy <steven.mccoy@miru.hk>" and "Steve-o 
<fnjordy@gmail.com>", are copyright of Steven McCoy.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

Steven McCoy
2019/02/24

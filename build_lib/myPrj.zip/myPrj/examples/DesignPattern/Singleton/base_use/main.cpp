#include "Singleton.h"
#include <iostream>

using namespace std;

int main()
{
	Singleton* sgn = Singleton::getInstance();
	
	return 0;
}
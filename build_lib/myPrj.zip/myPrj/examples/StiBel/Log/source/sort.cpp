#include"sort.h"
#include<iostream>

using namespace std;
using namespace algorithm::sort;


CREATE_STATIC_LOGGERMANAGER(Sort);


Sort::Sort()
{
	
	LogDebug("Sort Create");
	
	
}
Sort::~Sort()
{
	LogWarn("Sort End");
}

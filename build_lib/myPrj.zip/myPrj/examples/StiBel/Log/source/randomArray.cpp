#include"randomArray.h"
//#include"sort.h"
#include <stdio.h>
#include <stdlib.h>

using namespace algorithm::klc;

CREATE_STATIC_LOGGERMANAGER(randomArray);
randomArray::randomArray()
{
  LogInfo("randomArray create");
}
randomArray::~randomArray()
{
  
  LogError("randomArray End");
}


#!/bin/bash

proc="test"

make clean;make

./${proc} 
